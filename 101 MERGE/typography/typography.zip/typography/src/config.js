// Create config file
const contact = "xxx";
const mailingAddress = "contact@nomoretogo.co";
const unsubscribe =
  "https://click.mailerlite.com/link/c/YT0xOTM0MzU4ODYxNzU0NDA1OTgyJmM9bDhuNSZiPTk2MDM1NzY2OSZkPWo3eTJlNHY=.Ec_fY2NpMcOTAMs-XIr1n9exawt8fd3IsksWtSJ2kak";
const pathToImages = "../data/images/";
const pathMainLogo = "../data/images/logo.jpeg";
const pathSocialIcons = "../data/images/";
const titleHead =
  "Korean Barbecue Beef | Pork Schnitzel | Bahn Mi Meatball Skewers";

export {
  contact,
  mailingAddress,
  unsubscribe,
  pathToImages,
  pathMainLogo,
  pathSocialIcons,
  titleHead,
};
