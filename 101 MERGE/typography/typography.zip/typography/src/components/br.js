import {paragraphComponent} from 'html-typography-tags';

const brComponent = (attributes) => {
    const content = '';
    return paragraphComponent({attributes, content});
}

export default brComponent;